package project.nanodrgree.android.udacity.com.myapplication;

/**
 * Created by ARNAB on 2/3/2016.
 */
public class ToastDisplayConstants {

    public static final CharSequence SpotifySteamer_Text_Constant="This will launch my Spotify Steamer App";
    public static final CharSequence Score_Text_Constant="This will launch my Score App";
    public static final CharSequence Library_Text_Constant="This will launch my Library App";
    public static final CharSequence BuildIt_Text_Constant="This will launch my Build it bigger";
    public static final CharSequence XYZReader_Text_Constant="This will launch my XYZ Reader App";
    public static final CharSequence Capstone_Text_Constant="This will launch my Capstone App";

}
